"""RPG-related helper modules."""
