from __future__ import annotations

from typing import Dict, Any, List, Optional, Protocol, Tuple
import random
import json
import math

from .world_state import WorldState
from .events import Event, make_perception_from_event
from .data_models import NPC, PerceptionEvent
import json as _json_for_cfg  # local alias to avoid shadowing
from .tools.base import Tool
from .narrator import Narrator
from rpg import combat_rules
from .llm_client import LLMClient
# Optional UI renderer is injected externally; no import here to keep engine headless by default.

class RendererProtocol(Protocol):
    def set_board(self, top_locations: List[str], sublocations_map: Dict[str, List[str]]) -> None: ...
    def update_state(self, actors: List[Dict[str, Any]], messages: Dict[str, Any]) -> None: ...
    def run_once(self) -> Optional[Tuple[str, Any]]: ...
    def shutdown(self) -> None: ...


class Simulator:
    # NOTE: Backwards-compat alias kept for compatibility. Prefer run_one_npc_turn().
    def run_npc_round(self) -> bool:
        """Deprecated alias. Use run_one_npc_turn()."""
        return self.run_one_npc_turn()

    def run_one_npc_turn(self) -> bool:
        """Execute exactly one NPC (blocking on LLM). Do NOT advance time here.
        Returns True if an NPC acted; False if the cycle completed (no NPC acted)."""
        try:
            from .npc_planner import NPCPlanner
            planner = NPCPlanner(getattr(self, "llm", None))
        except Exception:
            planner = None

        world = self.world
        player_id = getattr(self, "player_id", None)

        # Initialize or refresh turn order at cycle boundaries
        if not self.npc_turn_order or self.current_npc_index >= len(self.npc_turn_order):
            self.npc_turn_order = sorted([nid for nid in getattr(world, "npcs", {}).keys() if nid != player_id])
            self.current_npc_index = 0
            if not self.npc_turn_order:
                return False  # No NPCs at all

        # Find the next eligible NPC for this single step
        while self.current_npc_index < len(self.npc_turn_order):
            nid = self.npc_turn_order[self.current_npc_index]
            self.current_npc_index += 1

            npc = world.npcs.get(nid)
            if not npc:
                continue
            # Skip dead NPCs
            if "dead" in getattr(npc, "tags", {}).get("dynamic", []):
                continue
            # If actor is busy, skip this tick for that NPC (time will advance after an action below)
            if getattr(npc, "next_available_tick", 0) > self.game_tick:
                continue

            # Build compact context for planner
            loc_id = getattr(npc, "location_id", None)
            location_static = getattr(world, "locations_static", {}).get(loc_id, {})
            location_state = getattr(world, "locations_state", {}).get(loc_id, {})
            visible_npcs = location_state.get("occupants", [])
            visible_items = location_state.get("items", [])
            neighbors = list((location_state.get("connections_state") or {}).keys())

            persona = {
                "id": getattr(npc, "id", nid),
                "name": getattr(npc, "name", nid),
                "hp": getattr(npc, "hp", None),
                "attributes": getattr(npc, "attributes", {}),
                "skills": getattr(npc, "skills", {}),
                "tags": getattr(npc, "tags", {}),
                "short_term_memory": getattr(npc, "short_term_memory", []),
                # Expose LTM and core memories/goals so planner and LLM can use them directly.
                "memories": getattr(npc, "memories", []),
                "core_memories": getattr(npc, "core_memories", []),
                "goals": getattr(npc, "goals", []),
            }
            # Build live conversation snapshot for this actor from Simulator state
            convo_snapshot = None
            try:
                convo_id = self.actor_conversation.get(nid)
                if convo_id and convo_id in self.conversations:
                    c = self.conversations[convo_id]
                    convo_snapshot = {
                        "conversation_id": c.get("conversation_id"),
                        "participants": c.get("participants", []),
                        "current_speaker": c.get("current_speaker"),
                        "turn_order": c.get("turn_order", []),
                        "last_interaction_tick": c.get("last_interaction_tick"),
                    }
            except Exception:
                convo_snapshot = None

            ctx = {
                "game_tick": getattr(world, "game_tick", 0),
                "actor": persona,
                "location": {
                    "id": loc_id,
                    "static": {
                        "name": location_static.get("name"),
                        "description": location_static.get("description"),
                    },
                    "neighbors": neighbors,
                    "connections_state": location_state.get("connections_state", {}),
                    "occupants": visible_npcs,
                    "items": visible_items,
                },
                "available_tools": ["move","talk","talk_loud","scream","look","grab","drop","attack","inventory","stats","equip","unequip","analyze","eat","give","open","close","toggle_starvation","wait","rest","interject","leave_conversation"],
                "recent_memories": getattr(world, "recent_memories", []),
                "conversation": convo_snapshot,
            }

            # Blocking LLM call for exactly one NPC
            action = None
            if planner is not None:
                try:
                    action = planner.plan(ctx)
                    # If available, log hidden reasoning from last LLM response to run log (non-fatal)
                    try:
                        from .llm_client import LLMClient as _LLM
                        extractor = _LLM().extract_think
                        raw = ""
                        try:
                            with open("llm_last_response.txt", "r", encoding="utf-8") as f:
                                raw = f.read()
                        except Exception:
                            raw = ""
                        if raw:
                            think = extractor(raw)
                            if think:
                                print(f"[LLM think] npc_plan {nid}: {think}")
                    except Exception:
                        pass
                except Exception as e:
                    print("[NPCPlanner] Error planning for", nid, ":", e)

            if isinstance(action, dict) and "tool" in action:
                # Runtime guard: block conversation speech when it's not the actor's turn
                try:
                    tool_name = action.get("tool")
                    if ctx.get("conversation") and ctx["conversation"].get("current_speaker") != nid:
                        if tool_name in {"talk", "interject"}:
                            # Convert blocked speech into a visible wait action so a bubble appears.
                            action = {"tool": "wait", "params": {"ticks": 1}}
                except Exception:
                    pass

                if action:
                    try:
                        self.process_command(nid, action)
                    except Exception as e:
                        print("[Simulator] Failed to execute NPC action for", nid, ":", e)

                # Drain events produced during this NPC action synchronously without advancing time.
                # Do NOT push renderer state on each individual event; we push once per tick in tick().
                try:
                    while getattr(self, "event_queue", []):
                        ready_events = [e for e in self.event_queue if e.tick <= self.game_tick]
                        if not ready_events:
                            break
                        self.event_queue = [e for e in self.event_queue if e.tick > self.game_tick]
                        for evt in ready_events:
                            self.handle_event(evt)
                except Exception:
                    pass

                # Do not advance time here; advance once after the full NPC cycle completes
                return True  # One NPC acted; stop here to avoid overload

            # If planner returned no action or actor was blocked, continue scanning this cycle

        # If we reached here, we exhausted the list; reset to start a new cycle next time
        self.current_npc_index = 0
        return False
    def __init__(
        self,
        world: WorldState,
        narrator: Optional[Narrator] = None,
        player_id: Optional[str] = None,
    ):
        self.world = world
        # Optional external renderer adapter with a simple interface:
        #  - set_board(top_locations, sublocations_map)
        #  - update_state(actors, messages)
        #  - run_once() -> ("enter", loc) | ("back", None) | ("noop", None)
        #  - shutdown()
        self.renderer: Optional[RendererProtocol] = None
        self.game_tick = 0
        self.event_queue: List[Event] = []
        self.tools: Dict[str, Tool] = {}
        self.narrator = narrator or Narrator(world)
        self.player_id = player_id
        self.starvation_enabled = True
        self.llm: Optional[LLMClient] = None  # Initialized lazily on first use

        # Memory config knobs with runtime overrides from config/llm.json if present
        self.perception_buffer_size = 30
        self.retrieval_top_k = 6
        try:
            # Lazy read config; avoid hard dependency on path by asking world (if it exposes), else project default
            import os
            cfg_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "llm.json")
            if os.path.exists(cfg_path):
                with open(cfg_path, "r", encoding="utf-8") as f:
                    cfg = _json_for_cfg.load(f)
                mem = (cfg or {}).get("memory") or {}
                self.perception_buffer_size = int(mem.get("perception_buffer_size", self.perception_buffer_size))
                self.retrieval_top_k = int(mem.get("retrieval_top_k", self.retrieval_top_k))
        except Exception:
            pass
         
        # Turn tracking state
        self.current_npc_index = 0
        self.npc_turn_order = []

        # UI state
        self._last_actor_msgs: Dict[str, str] = {}
        self._ui_focus_location: Optional[str] = None
        # Internal meta payload for renderer (non-actor keys)
        self._ui_meta: Dict[str, Any] = {}

        # In-memory conversation state
        # conversations: {conversation_id: {participants, turn_order, current_speaker, start_tick, last_interaction_tick, history: [{speaker, tick, content}], location_id}}
        self.conversations: Dict[str, Dict[str, Any]] = {}
        # Map actor -> conversation_id (only one active conversation per actor for now)
        self.actor_conversation: Dict[str, str] = {}

        # Event dispatch table replacing long if/elif chain in handle_event
        self.event_handlers = {
            "describe_location": self._handle_describe_location,
            "move": self._handle_move,
            "grab": self._handle_grab,
            "drop": self._handle_drop,
            "eat": self._handle_eat,
            "attack_attempt": self._handle_attack_attempt,
            "attack_hit": self._handle_attack_hit,
            "attack_missed": self._handle_attack_missed,
            "damage_applied": self._handle_damage_applied,
            "talk": self._handle_talk,
            "talk_loud": self._handle_talk_loud,
            "scream": self._handle_scream,
            "inventory": self._handle_inventory,
            "stats": self._handle_stats,
            "equip": self._handle_equip,
            "unequip": self._handle_unequip,
            "analyze": self._handle_analyze,
            "give": self._handle_give,
            "toggle_starvation": self._handle_toggle_starvation,
            "open_connection": self._handle_open_close_connection,
            "close_connection": self._handle_open_close_connection,
            "npc_died": self._handle_npc_died,
            "wait": self._handle_wait,
            "rest": self._handle_rest,
            "leave_conversation": self._handle_leave_conversation,
        }

    def register_tool(self, tool: Tool):
        self.tools[tool.name] = tool

    def process_command(self, actor_id: str, command: Dict[str, Any]):
        tool = self.tools.get(command["tool"])
        actor = self.world.get_npc(actor_id)
        if not tool:
            raise ValueError(f"Unknown tool {command['tool']}")
        if actor.next_available_tick > self.game_tick:
            raise ValueError("Actor is busy")
        params = command.get("params", {})
        if not tool.validate_intent(params, self.world, actor):
            raise ValueError("Invalid intent")

        # Compute time cost per command to avoid shared Tool state issues.
        time_cost = getattr(tool, "time_cost", 1)
        if getattr(tool, "name", "") in {"wait", "rest"}:
            try:
                time_cost = max(1, int(params.get("ticks", 1)))
            except Exception:
                time_cost = 1

        events = tool.generate_events(params, self.world, actor, self.game_tick)
        self.event_queue.extend(events)
        actor.next_available_tick = self.game_tick + time_cost

    def npc_think(self, npc: NPC) -> Optional[Dict[str, Any]]:
        """Deprecated: Use NPCPlanner.plan via run_npc_round. Retained for compatibility."""
        try:
            from .npc_planner import NPCPlanner
            planner = NPCPlanner(getattr(self, "llm", None))
        except Exception:
            return None

        # Build a minimal context similar to run_npc_round for this NPC
        current_loc = self.world.find_npc_location(npc.id)
        if not current_loc:
            return None
        loc_state = self.world.get_location_state(current_loc)
        loc_static = self.world.get_location_static(current_loc)
        neighbors = list(loc_state.connections_state.keys())
        occupants = [oid for oid in loc_state.occupants if oid != npc.id]
        items_here = list(loc_state.items)

        persona = {
            "id": npc.id,
            "name": npc.name,
            "hp": npc.hp,
            "attributes": getattr(npc, "attributes", {}),
            "skills": getattr(npc, "skills", {}),
            "tags": npc.tags,
            "short_term_memory": getattr(npc, "short_term_memory", []),
            "memories": getattr(npc, "memories", []),
            "core_memories": getattr(npc, "core_memories", []),
            "goals": getattr(npc, "goals", []),
        }

        # Conversation snapshot from simulator state
        convo_snapshot = None
        try:
            convo_id = self.actor_conversation.get(npc.id)
            if convo_id and convo_id in self.conversations:
                c = self.conversations[convo_id]
                convo_snapshot = {
                    "conversation_id": c.get("conversation_id"),
                    "participants": c.get("participants", []),
                    "current_speaker": c.get("current_speaker"),
                    "turn_order": c.get("turn_order", []),
                    "last_interaction_tick": c.get("last_interaction_tick"),
                }
        except Exception:
            pass

        ctx = {
            "game_tick": getattr(self.world, "game_tick", 0),
            "actor": persona,
            "location": {
                "id": current_loc,
                "static": {
                    "name": loc_static.name if hasattr(loc_static, "name") else getattr(loc_static, "description", ""),
                    "description": getattr(loc_static, "description", ""),
                },
                "neighbors": neighbors,
                "connections_state": getattr(loc_state, "connections_state", {}),
                "occupants": occupants,
                "items": items_here,
            },
            "available_tools": list(self.tools.keys()),
            "recent_memories": getattr(self.world, "recent_memories", []),
            "conversation": convo_snapshot,
        }

        action = planner.plan(ctx)
        return action

    def tick(self):
        """
        Advance global time by one tick, apply world passive effects (e.g. hunger),
        and process any events scheduled for this tick. This does NOT make NPCs
        choose actions; NPC actions are executed explicitly via run_npc_round()
        between player turns.
        """
        self.game_tick += 1
        if self.starvation_enabled:
            hunger_events = self.world.update_hunger(self.game_tick)
            self.event_queue.extend(hunger_events)

        # Drain only events whose tick <= current
        ready_events = [e for e in self.event_queue if e.tick <= self.game_tick]
        self.event_queue = [e for e in self.event_queue if e.tick > self.game_tick]
        for event in ready_events:
            self.handle_event(event)
        # After all events for this tick have been handled and actor bubbles recorded, update the renderer once.
        self._renderer_push_state()

    def set_renderer(self, renderer_adapter: Any):
        """Attach a renderer adapter (pygame-based UI)."""
        # Allow Any for call sites, but store as Protocol-typed
        self.renderer = renderer_adapter  # type: ignore[assignment]
        try:
            # Build initial board from known locations and sublocations (simple: none for now)
            top_locations = list(self.world.locations_static.keys())
            # Build sublocations map from dynamic state (LocationState.sublocations)
            sub_map: Dict[str, List[str]] = {}
            for loc_id in top_locations:
                try:
                    loc_state = self.world.get_location_state(loc_id)
                    subs = getattr(loc_state, "sublocations", []) or []
                    sub_map[loc_id] = [str(s) for s in subs]
                except Exception:
                    sub_map[loc_id] = []
            if hasattr(self.renderer, "set_board"):
                self.renderer.set_board(top_locations, sub_map)  # type: ignore[call-arg]

            # Seed initial connections_state snapshot for UI
            try:
                # Dynamic connection status snapshot (directional)
                snapshot: Dict[str, Dict[str, Any]] = {}
                for loc_id, loc_state in self.world.locations_state.items():
                    cs = getattr(loc_state, "connections_state", {}) or {}
                    snap_entry: Dict[str, Any] = {}
                    for nid, meta in cs.items():
                        status = (meta or {}).get("status", "open")
                        snap_entry[str(nid)] = {"status": status}
                    snapshot[str(loc_id)] = snap_entry
                self._ui_meta["__connections_state__"] = snapshot
            except Exception:
                self._ui_meta["__connections_state__"] = {}

            # Deprecated static adjacency snapshot removed: layout now derives from dynamic connections_state.
            try:
                # Clean any legacy key if present
                if "__static_neighbors__" in self._ui_meta:
                    self._ui_meta.pop("__static_neighbors__", None)
            except Exception:
                pass

            # Track layout signature for dynamic world changes
            try:
                self._ui_meta["__layout_signature__"] = {
                    "tops": sorted([str(x) for x in self.world.locations_static.keys()]),
                    "subs": {str(k): list(map(str, getattr(self.world.get_location_state(k), "sublocations", []) or []))
                             for k in self.world.locations_static.keys()},
                }
            except Exception:
                self._ui_meta["__layout_signature__"] = {}

            # Push initial state
            self._renderer_push_state()
        except Exception:
            pass

    def _compact_actor_list(self) -> List[Dict[str, Any]]:
        """Build minimal list of actors with types and location labels for UI."""
        actors: List[Dict[str, Any]] = []
        for npc_id, npc in self.world.npcs.items():
            loc_id = self.world.find_npc_location(npc_id)
            if not loc_id:
                continue
            a_type = "player" if npc_id == self.player_id else "npc"
            # Simple enemy detection by tag
            if "enemy" in npc.tags.get("static", []) or "enemy" in npc.tags.get("dynamic", []):
                a_type = "enemy"
            # If the location state carries a chosen sublocation for this npc (optional future), read it; else None
            subloc = None
            try:
                st = self.world.get_location_state(loc_id)
                # Optional: if world stores an assignment map like occupants_by_subloc, we could read it here
                # For now keep None; clicking into sublocation view will just show empty hexes until populated.
            except Exception:
                pass
            actors.append({
                "id": npc_id,
                "name": npc.name,
                "type": a_type,
                "location": loc_id,
                "sublocation": subloc,
            })
        return actors

    def _renderer_push_state(self):
        if not getattr(self, "renderer", None):
            return
        try:
            # Detect structural world changes (dynamic layout) and notify renderer if needed
            try:
                prev_sig = (self._ui_meta or {}).get("__layout_signature__", {})
                cur_tops = sorted([str(x) for x in self.world.locations_static.keys()])
                cur_subs = {str(k): list(map(str, getattr(self.world.get_location_state(k), "sublocations", []) or []))
                            for k in self.world.locations_static.keys()}
                cur_sig = {"tops": cur_tops, "subs": cur_subs}
                if prev_sig != cur_sig:
                    # Update board on renderer
                    if hasattr(self.renderer, "set_board"):
                        self.renderer.set_board(cur_tops, cur_subs)  # type: ignore[call-arg]
                    # Emit event-like flag so UI can optionally react
                    self._ui_meta["world_layout_changed"] = True
                    self._ui_meta["__layout_signature__"] = cur_sig
                else:
                    self._ui_meta.pop("world_layout_changed", None)
            except Exception:
                pass

            # Merge UI meta into messages channel for renderer
            merged_msgs = dict(self._last_actor_msgs)
            try:
                if self._ui_meta:
                    for k, v in self._ui_meta.items():
                        merged_msgs[k] = v
                # Ensure connections_state snapshot is always present and enriched with directions
                if "__connections_state__" not in merged_msgs:
                    snapshot: Dict[str, Dict[str, Any]] = {}
                    for loc_id, loc_state in self.world.locations_state.items():
                        cs = getattr(loc_state, "connections_state", {}) or {}
                        snap_entry: Dict[str, Any] = {}
                        for nid, meta in cs.items():
                            status = (meta or {}).get("status", "open")
                            direction = (meta or {}).get("direction", None)
                            entry: Dict[str, Any] = {"status": status}
                            if direction:
                                entry["direction"] = direction
                            snap_entry[str(nid)] = entry
                        snapshot[str(loc_id)] = snap_entry
                    merged_msgs["__connections_state__"] = snapshot

                # Derive layout neighbors dynamically from current connections_state
                try:
                    layout_neighbors: Dict[str, Dict[str, bool]] = {}
                    for loc_id, loc_state in self.world.locations_state.items():
                        cs = getattr(loc_state, "connections_state", {}) or {}
                        undirected: Dict[str, bool] = {}
                        for neighbor_id in cs.keys():
                            undirected[str(neighbor_id)] = True
                        layout_neighbors[str(loc_id)] = undirected
                    # Keep key name for renderer compatibility
                    merged_msgs["__static_neighbors__"] = layout_neighbors
                except Exception as e:
                    try:
                        print(f"[Renderer] Failed to build dynamic layout neighbors: {e}")
                    except Exception:
                        pass
            except Exception:
                pass

            # Optional: filter messages/actors by focused location if set (basic example)
            actor_list = self._compact_actor_list()
            if self._ui_focus_location:
                try:
                    focus = self._ui_focus_location
                    actor_list = [a for a in actor_list if a.get("location") == focus]
                    merged_msgs["__focus__"] = {"location": focus}
                except Exception:
                    pass

            if hasattr(self.renderer, "update_state"):
                self.renderer.update_state(actor_list, merged_msgs)  # type: ignore[call-arg]
            # Allow renderer to process input and draw a frame
            cmd = self.renderer.run_once() if hasattr(self.renderer, "run_once") else None  # type: ignore[call-arg]
            if isinstance(cmd, tuple):
                kind, payload = cmd
                if kind == "enter" and isinstance(payload, str):
                    self._ui_focus_location = payload
                elif kind == "back":
                    self._ui_focus_location = None
        except Exception:
            pass

    def _record_actor_last_message(self, event: Event):
        """Store a compact JSON message for the chat bubble of the actor."""
        try:
            actor_key = event.actor_id or ""
            if not actor_key:
                return

            # Previously suppressed inventory/stats/analyze; now allow them so more actors display bubbles.
            # No early return here; all event types can create bubbles.

            # Filtered compact JSON: include only essential fields
            msg = {"t": event.event_type}
            if event.target_ids:
                msg["targets"] = event.target_ids
            if event.payload:
                payload = dict(event.payload)
                content = payload.get("content")
                if isinstance(content, str):
                    payload["content"] = content[:160]
                msg["p"] = payload
            self._last_actor_msgs[actor_key] = json.dumps(msg, ensure_ascii=False)
        except Exception:
            pass

    def handle_event(self, event: Event):
        handler = self.event_handlers.get(event.event_type)
        if handler:
            handler(event)
        else:
            # Fallback for simple world mutations without bespoke logic
            try:
                print(f"[Simulator] No handler for event_type='{event.event_type}'. Applying to world and narrating.")
            except Exception:
                pass
            self.world.apply_event(event)
            msg = self.narrator.render(event)
            if msg:
                print(msg)
        # Common post-processing
        self.record_perception(event)
        self._record_actor_last_message(event)
        self._gc_conversations()

    # --- Individual event handlers ---

    def _emit_narration(self, event: Event):
        try:
            msg = self.narrator.render(event)
            if msg:
                print(msg)
        except Exception:
            pass

    def _handle_describe_location(self, event: Event):
        self._emit_narration(event)

    def _handle_move(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)

    def _handle_grab(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)

    def _handle_drop(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)

    def _handle_eat(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)

    def _handle_attack_attempt(self, event: Event):
        attacker = self.world.get_npc(event.actor_id)
        target = self.world.get_npc(event.target_ids[0])
        result = combat_rules.resolve_attack(self.world, attacker, target)
        payload = {
            "to_hit": result["to_hit"],
            "target_ac": result["target_ac"],
        }
        if result["hit"]:
            payload["damage"] = result["damage"]
            self.event_queue.append(
                Event(
                    event_type="attack_hit",
                    tick=self.game_tick,
                    actor_id=event.actor_id,
                    target_ids=event.target_ids,
                    payload=payload,
                )
            )
            self.event_queue.append(
                Event(
                    event_type="damage_applied",
                    tick=self.game_tick,
                    actor_id=event.actor_id,
                    target_ids=event.target_ids,
                    payload={
                        "amount": result["damage"],
                        "damage_type": combat_rules.get_weapon(self.world, attacker).damage_type,
                    },
                )
            )
        else:
            self.event_queue.append(
                Event(
                    event_type="attack_missed",
                    tick=self.game_tick,
                    actor_id=event.actor_id,
                    target_ids=event.target_ids,
                    payload=payload,
                )
            )
        self._emit_narration(event)

    def _handle_attack_hit(self, event: Event):
        self._emit_narration(event)

    def _handle_attack_missed(self, event: Event):
        self._emit_narration(event)

    def _handle_damage_applied(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)
        target = self.world.get_npc(event.target_ids[0])
        if target.hp <= 0 and "dead" not in target.tags.get("dynamic", []):
            loc_id = self.world.find_npc_location(target.id)
            self.event_queue.append(
                Event(
                    event_type="npc_died",
                    tick=self.game_tick,
                    actor_id=target.id,
                    target_ids=[loc_id] if loc_id else [],
                )
            )

    def _handle_talk(self, event: Event):
        # Conversation flow handling:
        speaker_id = event.actor_id
        content = event.payload.get("content", "")
        target_id = event.payload.get("recipient_id") or (event.target_ids[0] if event.target_ids else None)
        payload_convo_id = event.payload.get("conversation_id")
        is_interject = bool(event.payload.get("interject"))
        current_loc = self.world.find_npc_location(speaker_id)

        if is_interject and isinstance(payload_convo_id, str):
            convo = self.conversations.get(payload_convo_id)
            if convo:
                # Validate co-location with conversation location
                if current_loc and current_loc == convo.get("location_id"):
                    # Add if not already a participant
                    if speaker_id not in convo["participants"]:
                        convo["participants"].append(speaker_id)
                        self.actor_conversation[speaker_id] = payload_convo_id
                        # Join at end of queue
                        if speaker_id != convo.get("current_speaker"):
                            if speaker_id not in convo.get("turn_order", []):
                                convo["turn_order"].append(speaker_id)
                    # If it is their turn right now, accept line; else just log as aside without turn advance
                    if convo.get("current_speaker") == speaker_id:
                        convo["history"].append({"speaker": speaker_id, "tick": self.game_tick, "content": content})
                        convo["last_interaction_tick"] = self.game_tick
                        self._emit_narration(event)
                        self._advance_conversation_turn(payload_convo_id, hint_target=target_id)
                    else:
                        # Allow interjecting content as history but don't advance turn
                        convo["history"].append({"speaker": speaker_id, "tick": self.game_tick, "content": content})
                        convo["last_interaction_tick"] = self.game_tick
                        self._emit_narration(event)
            return

        # Normal talk handling
        convo_id = self.actor_conversation.get(speaker_id)

        if convo_id is None:
            # Start a new conversation if possible
            location_id = current_loc
            participants = [speaker_id]
            if target_id:
                # Only add target if co-located
                if self.world.find_npc_location(target_id) == location_id:
                    participants.append(target_id)
            if len(participants) < 2:
                # Not enough participants for a convo; still narrate the line as standalone talk
                self._emit_narration(event)
            else:
                convo_id = f"convo_{speaker_id}_{self.game_tick}"
                self.conversations[convo_id] = {
                    "conversation_id": convo_id,
                    "participants": participants[:],
                    "turn_order": [pid for pid in participants if pid != speaker_id],
                    "current_speaker": speaker_id,
                    "start_tick": self.game_tick,
                    "last_interaction_tick": self.game_tick,
                    "history": [{"speaker": speaker_id, "tick": self.game_tick, "content": content}],
                    "location_id": location_id,
                }
                for pid in participants:
                    self.actor_conversation[pid] = convo_id
                self._emit_narration(event)
                # Advance turn: targeted speech moves target to front if in participants
                self._advance_conversation_turn(convo_id, hint_target=target_id)
        else:
            # Must be the speaker's turn
            convo = self.conversations.get(convo_id)
            if convo and convo.get("current_speaker") == speaker_id:
                # Append to history and narrate
                convo["history"].append({"speaker": speaker_id, "tick": self.game_tick, "content": content})
                convo["last_interaction_tick"] = self.game_tick
                self._emit_narration(event)
                # Advance turn
                self._advance_conversation_turn(convo_id, hint_target=target_id)

    def _handle_talk_loud(self, event: Event):
        self._emit_narration(event)

    def _handle_scream(self, event: Event):
        self._emit_narration(event)

    def _handle_inventory(self, event: Event):
        self._emit_narration(event)

    def _handle_stats(self, event: Event):
        self._emit_narration(event)

    def _handle_equip(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)

    def _handle_unequip(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)

    def _handle_analyze(self, event: Event):
        self._emit_narration(event)

    def _handle_give(self, event: Event):
        # Simple world mutation; expect payload with item_id/recipient_id for clarity but keep target_ids compat
        self.world.apply_event(event)
        self._emit_narration(event)

    def _handle_toggle_starvation(self, event: Event):
        self.starvation_enabled = event.payload.get("enabled", True)
        if not self.starvation_enabled:
            for npc in self.world.npcs.values():
                npc.hunger_stage = "sated"
                npc.last_meal_tick = self.game_tick
        self._emit_narration(event)

    def _handle_open_close_connection(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)
        # Push a fresh connections_state snapshot to UI meta so renderer can draw open/closed edges
        try:
            snapshot: Dict[str, Dict[str, Any]] = {}
            for loc_id, loc_state in self.world.locations_state.items():
                try:
                    # Keep only neighbor->{"status": ...}
                    cs = getattr(loc_state, "connections_state", {}) or {}
                    snap_entry: Dict[str, Any] = {}
                    for nid, meta in cs.items():
                        try:
                            status = (meta or {}).get("status", "open")
                        except Exception:
                            status = "open"
                        snap_entry[str(nid)] = {"status": status}
                    snapshot[str(loc_id)] = snap_entry
                except Exception:
                    continue
            # Store under a reserved key consumed by renderer.update_state
            self._ui_meta["__connections_state__"] = snapshot
        except Exception:
            pass

    def _handle_npc_died(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)
        # Prune last message cache for dead actors to avoid unbounded growth
        try:
            if event.actor_id:
                self._last_actor_msgs.pop(event.actor_id, None)
        except Exception:
            pass

    def _handle_wait(self, event: Event):
        self._emit_narration(event)

    def _handle_rest(self, event: Event):
        self.world.apply_event(event)
        self._emit_narration(event)

    def _handle_leave_conversation(self, event: Event):
        # Remove actor from their active conversation
        self._leave_conversation(event.actor_id)

    def record_perception(self, event: Event):
        """Add a simplified perception entry to actors in the same or adjacent locations per rules."""
        if event.event_type in {"describe_location", "wait"}:
            return

        # Determine the primary location where the event is perceived
        if event.event_type == "move":
            location_id = event.target_ids[0] if event.target_ids else None
        elif event.event_type == "npc_died":
            location_id = event.target_ids[0] if event.target_ids else None
        else:
            location_id = self.world.find_npc_location(event.actor_id)

        if not location_id:
            return

        recipients: set[str] = set()
        try:
            loc_state = self.world.get_location_state(location_id)
            # Same-location recipients (excluding the actor)
            for npc_id in getattr(loc_state, "occupants", []):
                if npc_id != event.actor_id:
                    recipients.add(npc_id)
        except Exception:
            pass

        # Noise propagation rules
        try:
            if event.event_type in {"scream", "talk_loud"}:
                loc_static = self.world.get_location_static(location_id)
                state_here = self.world.get_location_state(location_id)
                for neighbor_id in getattr(loc_static, "hex_connections", {}).values():
                    conn = getattr(state_here, "connections_state", {}).get(neighbor_id, {})
                    is_open = conn.get("status", "open") == "open"
                    if event.event_type == "scream" or is_open:
                        neighbor_state = self.world.get_location_state(neighbor_id)
                        for npc_id in getattr(neighbor_state, "occupants", []):
                            # If neighbor location has an elevated_vantage_point tag, allow perception even if door closed (visual), but this block is for audio
                            recipients.add(npc_id)
        except Exception:
            pass

        # Append as structured PerceptionEvent objects and cap buffer
        for npc_id in recipients:
            try:
                npc = self.world.get_npc(npc_id)
                # Elevated vantage point: allow additional cross-location perception for visual events even if door closed
                try:
                    visual_events = {"grab","drop","equip","unequip","attack_hit","attack_missed","damage_applied","inventory","stats","analyze"}
                    if event.event_type in visual_events:
                        # If recipient has elevated_vantage_point inherent tag, they can also perceive from neighbors
                        tags = (npc.tags or {})
                        inh = set((tags.get("inherent") or []))
                        if "elevated_vantage_point" in inh:
                            # No extra work here beyond inclusion; rule already increases recipients earlier
                            pass
                except Exception:
                    pass
                pe: PerceptionEvent = make_perception_from_event(event, location_id=location_id)
                npc.short_term_memory.append(pe)
                # Cap STM size using configured buffer
                cap = max(1, int(getattr(self, "perception_buffer_size", 30)))
                while len(npc.short_term_memory) > cap:
                    npc.short_term_memory.pop(0)
            except Exception:
                continue

    # Conversation helpers
    def _advance_conversation_turn(self, convo_id: str, hint_target: Optional[str] = None):
        convo = self.conversations.get(convo_id)
        if not convo:
            return
        current = convo.get("current_speaker")
        turn_order: List[str] = convo.get("turn_order", [])
        participants: List[str] = convo.get("participants", [])

        # Ensure turn_order only contains current participants except current speaker
        turn_order = [p for p in turn_order if p in participants and p != current]

        # Target rule: if hint_target in participants, move it to the front
        if hint_target and hint_target in participants and hint_target != current:
            # Ensure target is in queue at most once, then move to front
            turn_order = [pid for pid in turn_order if pid != hint_target]
            turn_order.insert(0, hint_target)

        # Move current to end
        if current and current in participants:
            turn_order.append(current)

        # Pop next speaker
        next_speaker = turn_order.pop(0) if turn_order else None
        convo["turn_order"] = turn_order
        convo["current_speaker"] = next_speaker
        convo["last_interaction_tick"] = self.game_tick

        # Dissolve if fewer than 2 participants remain
        if len(participants) < 2 or not next_speaker:
            self._dissolve_conversation(convo_id)

    def _leave_conversation(self, actor_id: str):
        convo_id = self.actor_conversation.get(actor_id)
        if not convo_id:
            return
        convo = self.conversations.get(convo_id)
        if not convo:
            self.actor_conversation.pop(actor_id, None)
            return
        participants: List[str] = convo.get("participants", [])
        if actor_id in participants:
            participants.remove(actor_id)
        # Remove from queues
        if actor_id == convo.get("current_speaker"):
            # If others remain, immediately advance to next speaker rather than setting None
            convo["current_speaker"] = None
            # Advance turn to keep flow going
            self._advance_conversation_turn(convo_id)
        # Remove from queues
        convo["turn_order"] = [p for p in convo.get("turn_order", []) if p != actor_id]
        self.actor_conversation.pop(actor_id, None)
        # Dissolve if fewer than 2 participants
        if len(participants) < 2:
            self._dissolve_conversation(convo_id)
        else:
            convo["last_interaction_tick"] = self.game_tick

    def _dissolve_conversation(self, convo_id: str):
        convo = self.conversations.pop(convo_id, None)
        if not convo:
            return
        for pid in list(convo.get("participants", [])):
            if self.actor_conversation.get(pid) == convo_id:
                self.actor_conversation.pop(pid, None)

    def _gc_conversations(self, timeout: int = 300):
        # Remove conversations that are stale or location participants dispersed
        to_remove = []
        for convo_id, convo in self.conversations.items():
            if self.game_tick - convo.get("last_interaction_tick", 0) > timeout:
                to_remove.append(convo_id)
                continue
            # If participants are no longer co-located, dissolve
            loc = convo.get("location_id")
            if not loc:
                continue
            still_here = [pid for pid in convo.get("participants", []) if self.world.find_npc_location(pid) == loc]
            if len(still_here) < 2:
                to_remove.append(convo_id)
        for cid in to_remove:
            self._dissolve_conversation(cid)
