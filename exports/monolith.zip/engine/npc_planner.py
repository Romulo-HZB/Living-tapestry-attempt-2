from typing import Dict, Optional, Any, List, Tuple
from .llm_client import LLMClient
from .data_models import Memory
import json
import re

PLANNER_SYSTEM_PROMPT = (
    "You are an action planner for a deterministic text-sim.\n"
    "Return ONLY a single JSON object: {\"tool\": string, \"params\": object} or null.\n"
    "No prose, no code fences.\n"
    "Valid tools: [\"move\",\"talk\",\"talk_loud\",\"scream\",\"look\",\"grab\",\"drop\",\"attack\",\"inventory\",\"stats\",\"equip\",\"unequip\",\"analyze\",\"eat\",\"give\",\"open\",\"close\",\"toggle_starvation\",\"wait\",\"rest\",\"interject\",\"leave_conversation\"].\n"
    "Rules:\n"
    "- Choose exactly one tool per turn.\n"
    "- Keep params minimal and valid; prefer IDs from context.\n"
    "- If no sensible action, return null.\n"
    "- If in a conversation and not current speaker, return null.\n"
    "- Working memory is provided; consider goals, core memories, and recent perceptions when deciding.\n"
    "- When idle: prefer varied low-impact actions like talk with short emotes (e.g., \"nods.\", \"hums.\"), or wait; avoid repeating the same action consecutively.\n"
    "- Avoid selecting \"look\" more than once every 5 turns; use it sparingly.\n"
    "- Use \"move\" only to open neighbors.\n"
    "- Use \"attack\" only if co-located and context justifies.\n"
    "- For durations like wait/rest without a number, use ticks=1.\n"
    "\n"
    "Embodiment and action:\n"
    "You are controlling a single embodied actor in a physical world. Choose exactly one concrete next action that physically advances the actor’s goal (e.g., move toward a target, open/close a door, talk/talk_loud when speech itself advances the goal).\n"
    "\n"
    "Navigation:\n"
    "If you intend to \"investigate\" something not in your current location, choose move toward the relevant neighbor. Use neighbors and connections_state from context.location to pick a valid target location. If a connection is closed, choose open (or close when appropriate) or try an alternate route.\n"
    "\n"
    "Targeted speech:\n"
    "Only use talk/talk_loud when speech itself advances the goal. When speaking to someone present, include target_id to direct speech. If the relevant person is elsewhere, move toward a likely location instead of just promising to go.\n"
    "\n"
    "Avoid empty promises:\n"
    "Do not merely announce intentions. Act: if you say you will check a gate or room, actually move toward it.\n"
    "\n"
    "Repetition hint:\n"
    "You receive repetition_hint = {last_tool_by_actor, avoid_repeat_within, look_cooldown}. Do not pick last_tool_by_actor again within avoid_repeat_within turns unless necessary. Avoid 'look' if within look_cooldown. If you previously indicated you would investigate, prefer move next.\n"
    "\n"
    "Hidden reasoning:\n"
    "Before deciding, write brief hidden reasoning inside <think>...</think>. Then output ONLY one JSON object with the command.\n"
)

def _tokenize(text: str) -> List[str]:
    text = (text or "").lower()
    return re.findall(r"[a-z0-9_]+", text)

def _score_memory(keywords: List[str], m: Memory) -> float:
    if not isinstance(m, Memory):
        # Legacy dict fallback
        blob = json.dumps(m, ensure_ascii=False)
        txt = blob
        tick = (m.get("tick") if isinstance(m, dict) else 0) or 0
        score = 0.0
        for k in keywords:
            if k in txt.lower():
                score += 1.0
        # recency boost
        score += min(2.0, tick / 100000.0)
        return score
    score = 0.0
    txt = f"{m.text} {json.dumps(m.payload, ensure_ascii=False)}".lower()
    for k in keywords:
        if k in txt:
            score += 1.0
    # status weighting
    if getattr(m, "status", "active") == "archived":
        score *= 0.6
    elif getattr(m, "status", "active") in {"recalled", "active"}:
        score *= 1.0
    elif getattr(m, "status", "active") == "consolidated":
        score *= 1.2
    # confidence weighting
    try:
        score *= max(0.3, min(1.2, float(getattr(m, "confidence", 1.0))))
    except Exception:
        pass
    # recency boost
    try:
        score += min(2.0, float(getattr(m, "tick", 0)) / 100000.0)
    except Exception:
        pass
    return score

def _memory_to_dict(m: Any) -> Any:
    try:
        # Avoid importing dataclasses.asdict to keep deps light; Memory likely has __dict__
        if isinstance(m, Memory):
            return {
                "text": getattr(m, "text", ""),
                "tick": getattr(m, "tick", 0),
                "priority": getattr(m, "priority", "normal"),
                "status": getattr(m, "status", "active"),
                "source_id": getattr(m, "source_id", None),
                "confidence": getattr(m, "confidence", 1.0),
                "is_secret": getattr(m, "is_secret", False),
                "payload": getattr(m, "payload", {}) or {},
            }
        if isinstance(m, dict):
            return m
    except Exception:
        pass
    return m

def build_working_memory(context: Dict[str, Any], retrieval_top_k: int = 6, max_stm: int = 10) -> Dict[str, Any]:
    """
    Build a compact working memory slice from actor data:
    - goals (top few)
    - core_memories
    - short_term_memory (recent perception events)
    - retrieved long-term memories (keyword search)
    """
    actor = context.get("actor") or {}
    wm: Dict[str, Any] = {}
    # goals
    goals = (actor.get("goals") or []) if isinstance(actor.get("goals"), list) else []
    wm["goals"] = goals[:5]
    # core memories
    core = (actor.get("core_memories") or []) if isinstance(actor.get("core_memories"), list) else []
    wm["core_memories"] = core[:10]
    # short-term perception
    stm = (actor.get("short_term_memory") or []) if isinstance(actor.get("short_term_memory"), list) else []
    wm["perceptions"] = stm[-max_stm:]
    # build keyword set from recent perception payloads + conversation + location/topic hints
    keywords: List[str] = []
    # actor name/id
    for k in _tokenize(actor.get("name") or "") + _tokenize(actor.get("id") or ""):
        if k not in keywords:
            keywords.append(k)
    # location/topic
    loc = context.get("location") or {}
    for k in _tokenize((loc.get("static") or {}).get("description") or ""):
        if k not in keywords:
            keywords.append(k)
    convo = context.get("conversation") or {}
    for h in (convo.get("history") or [])[-4:]:
        if isinstance(h, dict):
            for k in _tokenize(h.get("content") or ""):
                if k not in keywords:
                    keywords.append(k)
    for p in stm[-max_stm:]:
        if isinstance(p, dict):
            payload = p.get("payload") or {}
            for k in _tokenize(json.dumps(payload, ensure_ascii=False)):
                if k not in keywords:
                    keywords.append(k)
    # retrieve from LTM provided in context.actor.memories if present; planner gets NPC objects indirectly,
    # but the simulator currently passes persona without full memories. If present, use it. Else, empty list.
    ltm: List[Any] = actor.get("memories") or []
    scored: List[Tuple[float, Any]] = []
    for m in ltm:
        try:
            if isinstance(m, Memory):
                scored.append((_score_memory(keywords, m), m))
            else:
                scored.append((_score_memory(keywords, m), m))
        except Exception:
            continue
    scored.sort(key=lambda t: t[0], reverse=True)
    top = [m for _, m in scored[:retrieval_top_k]]
    # Ensure JSON-safe
    wm["retrieved_memories"] = [_memory_to_dict(m) for m in top]
    # Also ensure core/goals/perceptions are JSON-safe if they accidentally contain dataclasses
    wm["core_memories"] = [_memory_to_dict(m) for m in wm.get("core_memories", [])]
    # Ensure Goal dataclasses are serializable
    def _goal_to_dict(g: Any) -> Any:
        if isinstance(g, dict):
            return g
        try:
            return {
                "text": getattr(g, "text", ""),
                "type": getattr(g, "type", "note"),
                "priority": getattr(g, "priority", "normal"),
                "status": getattr(g, "status", "active"),
                "payload": getattr(g, "payload", {}) or {},
                "expiry_tick": getattr(g, "expiry_tick", None),
            }
        except Exception:
            return getattr(g, "__dict__", g)
    wm["goals"] = [_goal_to_dict(g) for g in wm.get("goals", [])]
    # PerceptionEvent dataclasses may appear; convert robustly
    def _perception_to_dict(p: Any) -> Any:
        if isinstance(p, dict):
            return p
        try:
            return {
                "event_type": getattr(p, "event_type", getattr(p, "type", "")),
                "tick": getattr(p, "tick", 0),
                "actor_id": getattr(p, "actor_id", None),
                "target_ids": list(getattr(p, "target_ids", []) or []),
                "payload": getattr(p, "payload", {}) or {},
                "location_id": getattr(p, "location_id", None),
            }
        except Exception:
            return getattr(p, "__dict__", p)
    wm["perceptions"] = [_perception_to_dict(p) for p in wm.get("perceptions", [])]
    return wm

class NPCPlanner:
    def __init__(self, llm: Optional[LLMClient] = None) -> None:
        self.llm = llm or LLMClient()

    def plan(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        # Compose repetition hints from STM
        stm = ((context.get("actor") or {}).get("short_term_memory") or [])
        last_tool = None
        actor_id = (context.get("actor") or {}).get("id")
        for m in reversed(stm[-6:]):
            if isinstance(m, dict) and m.get("actor_id") == actor_id:
                last_tool = m.get("event_type")
                break
        repetition_hint = {"last_tool_by_actor": last_tool, "avoid_repeat_within": 2, "look_cooldown": 5}

        # Build working memory slice and attach to the context sent to the model
        working_memory = build_working_memory(context)

        # Sanitize actor.memories in the outer context to avoid dataclass leakage
        ctx_copy = dict(context)
        actor_copy = dict(ctx_copy.get("actor") or {})
        if isinstance(actor_copy.get("memories"), list):
            actor_copy["memories"] = [_memory_to_dict(m) for m in actor_copy["memories"]]
        if isinstance(actor_copy.get("core_memories"), list):
            actor_copy["core_memories"] = [_memory_to_dict(m) for m in actor_copy["core_memories"]]
        # Sanitize goals as well
        def _goal_to_dict(g: Any) -> Any:
            if isinstance(g, dict):
                return g
            try:
                return {
                    "text": getattr(g, "text", ""),
                    "type": getattr(g, "type", "note"),
                    "priority": getattr(g, "priority", "normal"),
                    "status": getattr(g, "status", "active"),
                    "payload": getattr(g, "payload", {}) or {},
                    "expiry_tick": getattr(g, "expiry_tick", None),
                }
            except Exception:
                return getattr(g, "__dict__", g)
        if isinstance(actor_copy.get("goals"), list):
            actor_copy["goals"] = [_goal_to_dict(g) for g in actor_copy["goals"]]
        # Sanitize short_term_memory as well (PerceptionEvent)
        if isinstance(actor_copy.get("short_term_memory"), list):
            def _perception_to_dict(p: Any) -> Any:
                if isinstance(p, dict):
                    return p
                try:
                    return {
                        "event_type": getattr(p, "event_type", getattr(p, "type", "")),
                        "tick": getattr(p, "tick", 0),
                        "actor_id": getattr(p, "actor_id", None),
                        "target_ids": list(getattr(p, "target_ids", []) or []),
                        "payload": getattr(p, "payload", {}) or {},
                        "location_id": getattr(p, "location_id", None),
                    }
                except Exception:
                    return getattr(p, "__dict__", p)
            actor_copy["short_term_memory"] = [_perception_to_dict(p) for p in actor_copy["short_term_memory"]]
        # Ensure available_tools is JSON-serializable (it may contain objects in some paths)
        if isinstance(ctx_copy.get("available_tools"), list):
            ctx_copy["available_tools"] = [t if isinstance(t, str) else str(getattr(t, "name", t)) for t in ctx_copy["available_tools"]]
        ctx_copy["actor"] = actor_copy

        # Optionally add a concise neighbor names mapping to aid navigation if available in location static data.
        # This is additive context only; engine/tool schemas remain unchanged.
        loc_static = ((context.get("location") or {}).get("static") or {})
        neighbor_names = {}
        try:
            # If static location data exposes neighbor metadata, include short labels
            # Expecting something like {"neighbors": {"loc_id": {"name": "East Gate"}}}
            ns = (loc_static.get("neighbors") or {})
            if isinstance(ns, dict):
                for nid, nmeta in ns.items():
                    if isinstance(nmeta, dict):
                        label = nmeta.get("name") or nmeta.get("label") or str(nid)
                    else:
                        label = str(nmeta)
                    neighbor_names[str(nid)] = str(label)[:40]
        except Exception:
            neighbor_names = {}

        user_payload = {
            "context": ctx_copy,
            "working_memory": working_memory,
            "repetition_hint": repetition_hint,
            "neighbor_names": neighbor_names,
            "input": "Decide the next action. Respect repetition_hint.last_tool_by_actor and avoid repeating the same tool within repetition_hint.avoid_repeat_within turns. Do not choose look if last use was within look_cooldown turns."
        }
        messages = [
            {"role": "system", "content": PLANNER_SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(user_payload)},
        ]
        reply = self.llm.chat(messages)
        extractor = getattr(self.llm, "_strip_think_and_extract_json", None)
        parsed = extractor(reply) if callable(extractor) else None

        if parsed is None:
            return None
        if isinstance(parsed, dict):
            tool = parsed.get("tool")
            params = parsed.get("params", {})
            if tool is None or (isinstance(tool, str) and tool.strip().lower() in {"null", "none"}):
                return None
            if not isinstance(params, dict):
                params = {}
            valid_tools = {
                "move","talk","talk_loud","scream","look","grab","drop","attack",
                "inventory","stats","equip","unequip","analyze","eat","give",
                "open","close","toggle_starvation","wait","rest","interject","leave_conversation",
                # Intentionally excluding reason/reflect unless explicitly enabled
            }
            if tool not in valid_tools:
                return None
            # Defensive normalization for frequent LLM mistakes:
            # - accept 'target' or 'target_id' for attack, convert to 'target_ids' list if engine expects that
            if tool == "attack":
                tgt = params.get("target_id") or params.get("target") or params.get("target_ids")
                if isinstance(tgt, list):
                    # keep first if list provided
                    params = {"target_id": tgt[0] if tgt else None}
                elif isinstance(tgt, str):
                    params = {"target_id": tgt}
                else:
                    # invalid intent; let simulator reject gracefully
                    params = {}
            # - For talk, ensure 'content' is a short string
            if tool in {"talk","talk_loud","scream"}:
                content = params.get("content")
                if not isinstance(content, str):
                    params["content"] = "..."
                else:
                    params["content"] = content[:200]
            # - For move, accept either 'target' or 'location_id'
            if tool == "move":
                loc = params.get("location_id") or params.get("target") or params.get("to")
                if isinstance(loc, str):
                    params = {"location_id": loc}
            return {"tool": tool, "params": params}
        return None
